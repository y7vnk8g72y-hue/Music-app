MY MUSIC — PWA

This is an installable Progressive Web App version of the music player.

IMPORTANT:
A service worker and PWA installation require the app to be served over HTTPS
(or localhost during development). Opening index.html directly with file://
will not enable installation.

EASIEST METHOD:
1. Put these files on a GitHub repository.
2. Enable GitHub Pages for the repository.
3. Open the resulting https://...github.io/... address in Chrome or Edge.
4. Use the browser's Install App / Install My Music option.
5. The installed app can then be launched like a normal app.

BACKGROUND AUDIO:
The HTML audio element can continue playing when the installed PWA is
minimized/backgrounded, subject to the operating system and browser.
The service worker itself does NOT play audio; it makes the app installable
and available offline.

FILES:
- index.html   Main app
- manifest.json PWA installation information
- sw.js        Offline/service-worker cache
- icon.svg     App icon
